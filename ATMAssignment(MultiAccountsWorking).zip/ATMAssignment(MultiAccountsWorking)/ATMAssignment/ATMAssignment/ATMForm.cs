﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATMAssignment
{
    public partial class ATMForm : Form
    {
        private Account activeAccount = null;
        Button[] numberpad = new Button[12];
        string value = "";
        int stage = 0;
        string pin = "";
        int[] withdrawAmount = { 10, 20, 40, 100, 500 };

        public ATMForm()
        {
            InitializeComponent();
            InitializeNumberPad();
            panelOptions.Visible = false;
        }

        /*
         * Method to Inlitialise the numberpad
         *
         */ 
        private void InitializeNumberPad() {
            //Initlising Numberpad
            for (int i = 0; i < 9; i++)
            {
                //Inlitialising button
                numberpad[i] = new Button();
                numberpad[i].Text = Convert.ToString(i + 1);
                numberpad[i].Width = 60;
                numberpad[i].Height = 60;
                numberpad[i].Click += new EventHandler(this.BtnNumberPadEvent_Click);

                //Adding button to panel
                NumberPadFlowPanel.Controls.Add(numberpad[i]);
            }

            for (int i = 9; i < 12; i++)
            {
                //Inlitialising button
                numberpad[i] = new Button();
                numberpad[i].Width = 60;
                numberpad[i].Height = 60;
                numberpad[i].Click += new EventHandler(this.BtnNumberPadEvent_Click);

                //Adding button to panel
                NumberPadFlowPanel.Controls.Add(numberpad[i]);
            }

            numberpad[9].Text = "0";
            numberpad[10].Text = ".";
            
        }

        private void GetAcountNumberFromUser() {
            UserEnteredAccountNumber.Text += value;

            //Check if value is not empty
            if (UserEnteredAccountNumber.Text.Length == 6)
            {
                stage = 1;
                value = "";

                //Move the highlight
                PinLabel.BackColor = Color.WhiteSmoke;
                AccountLabel.BackColor = Color.RoyalBlue;
            }

            
        }

        private void GetPinNumberFromUser(){

            UserEnteredPinNumber.Text += "*";
            pin += value;

            if (UserEnteredPinNumber.Text.Length == 4) {
                stage = 2;
                value = "";

                //Move the highlight
                lEnter.BackColor = Color.WhiteSmoke;
                PinLabel.BackColor = Color.RoyalBlue;
            }

          
    }


        void BtnNumberPadEvent_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            value = btn.Text;
            switch (stage)
            {
                case 0: GetAcountNumberFromUser(); break;

                case 1: GetPinNumberFromUser(); break;

                default: break;

            }
        }

        private void DisplayOptions()
        {
            stage = 3;
            lOption1.Text = "Withdraw money from account";
            lOption2.Text = "Check account balance";
            lOption3.Text = "Return card";
            lOption4.Visible = false;
            lOption5.Visible = false;
            BtnOption3.BackColor = Color.Red;
        }

        /*
         *    this method finds an account with the account number the user entered
         *    the string account number is converted to an int then
         *    a for loop is used to check the entered account number
         *    against those held in the account array
         *    if a match is found a reference to the match is returned
         *    if the for loop completes with no match we return null
         * 
         */
        private Account FindAccount()
        {
            int input = Convert.ToInt32(UserEnteredAccountNumber.Text);

            for (int i = 0; i < Program.ac.Length; i++)
            {
                if (Program.ac[i].getAccountNum() == input)
                {
                    return Program.ac[i];
                }
            }

            return null;
        }

        //checks if the user has entered a valid account with the correct pin
        private void ValidateAccount()
        {
            activeAccount = FindAccount();
            if (activeAccount == null)
            {
                Cancel();
                MessageBox.Show("Incorrect Account Details");
            }
            else
            {
                int intPin = Convert.ToInt32(pin);
                if (activeAccount.checkPin(intPin))
                {
                    MessageBox.Show("Welcome To Your Account");
                    panelOptions.Visible = true;
                    DisplayOptions();
                }
                else
                {
                    Cancel();
                    MessageBox.Show("Incorrect Account Details");
                }
            }
        }

        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            if(stage == 2)
            {
                ValidateAccount();
            }
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult aboutDialog = new DialogResult();
            aboutDialog = MessageBox.Show("Multi Threaded ATM programmed in C# by Naqash Nadeem, Nicole Orr and Melvin Abraham", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnOption3_Click(object sender, EventArgs e)
        {
            switch (stage)
            {
                case 0: Cancel(); break;

                case 1: Cancel(); break;

                case 2: Cancel(); break;

                case 3:
                    Cancel();
                    MessageBox.Show("Returning card...");
                    panelOptions.Visible = false;
                    break;

                case 4: Withdraw(withdrawAmount[2]);  break; //used to select amount

                case 5: DisplayOptions(); break; //used to return to account options

                default: break;

            }
        }

        private void Cancel()
        {
            //clear stored values
            activeAccount = null;
            UserEnteredAccountNumber.Text = "";
            UserEnteredPinNumber.Text = "";
            pin = "";
            stage = 0;

            //Move the highlight
            AccountLabel.BackColor = Color.WhiteSmoke;
            PinLabel.BackColor = Color.RoyalBlue;
            lEnter.BackColor = Color.RoyalBlue;
        }

        private void Withdraw(int amount)
        {
            Boolean withdrawn = activeAccount.decrementBalance(amount);
            if(withdrawn)
            {
                MessageBox.Show("Withdrawing £" + amount);
            }
            else
            {
                MessageBox.Show("Insufficient Funds");
            }

            //display account options
            DisplayOptions();
        }

        private void BtnOption1_Click(object sender, EventArgs e)
        {
            if (stage == 3)
            {
                stage = 4;
                BtnOption3.BackColor = Color.LightGray;

                //display withdraw options
                lOption1.Text = "£" + withdrawAmount[0];
                lOption2.Text = "£" + withdrawAmount[1];
                lOption3.Text = "£" + withdrawAmount[2];
                lOption4.Visible = true;
                lOption5.Visible = true;
            }
            else if (stage == 4)
            {
                Withdraw(withdrawAmount[0]);
            }
        }

        private void BtnOption2_Click(object sender, EventArgs e)
        {
            if (stage == 3)
            {
                stage = 5;

                //display balance
                lOption1.Text = "Account Balance:";
                lOption2.Text = "£" + activeAccount.getBalance();
                lOption3.Text = "Return";
                
            }
            else if (stage == 4)
            {
                Withdraw(withdrawAmount[1]);
            }
        }

        private void BtnOption4_Click(object sender, EventArgs e)
        {
            if (stage == 4)
            {
                Withdraw(withdrawAmount[3]);
            }
        }

        private void BtnOption5_Click(object sender, EventArgs e)
        {
            if (stage == 4)
            {
                Withdraw(withdrawAmount[4]);
            }
        }

        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
}

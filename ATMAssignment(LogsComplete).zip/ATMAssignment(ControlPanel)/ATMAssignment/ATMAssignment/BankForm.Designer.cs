﻿namespace ATMAssignment
{
    partial class BankForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton1RaceConditionOffRadioBtn = new System.Windows.Forms.RadioButton();
            this.RaceConditionOnRadioBtn = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.RaceConditionLable = new System.Windows.Forms.Label();
            this.NumberOfAtmLable = new System.Windows.Forms.Label();
            this.BtnLaunch = new System.Windows.Forms.Button();
            this.BtnViewLogs = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listView1 = new System.Windows.Forms.ListView();
            this.ch_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(54, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(483, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Central Bank Computer : Control Panel";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(452, 360);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 34);
            this.button1.TabIndex = 3;
            this.button1.Text = "Retrun";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButton1RaceConditionOffRadioBtn);
            this.panel1.Controls.Add(this.RaceConditionOnRadioBtn);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.RaceConditionLable);
            this.panel1.Controls.Add(this.NumberOfAtmLable);
            this.panel1.Controls.Add(this.BtnLaunch);
            this.panel1.Controls.Add(this.BtnViewLogs);
            this.panel1.Location = new System.Drawing.Point(14, 65);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(569, 329);
            this.panel1.TabIndex = 4;
            // 
            // radioButton1RaceConditionOffRadioBtn
            // 
            this.radioButton1RaceConditionOffRadioBtn.AutoSize = true;
            this.radioButton1RaceConditionOffRadioBtn.Location = new System.Drawing.Point(470, 128);
            this.radioButton1RaceConditionOffRadioBtn.Name = "radioButton1RaceConditionOffRadioBtn";
            this.radioButton1RaceConditionOffRadioBtn.Size = new System.Drawing.Size(39, 17);
            this.radioButton1RaceConditionOffRadioBtn.TabIndex = 6;
            this.radioButton1RaceConditionOffRadioBtn.TabStop = true;
            this.radioButton1RaceConditionOffRadioBtn.Text = "Off";
            this.radioButton1RaceConditionOffRadioBtn.UseVisualStyleBackColor = true;
            this.radioButton1RaceConditionOffRadioBtn.CheckedChanged += new System.EventHandler(this.radioButton1RaceConditionOffRadioBtn_CheckedChanged);
            // 
            // RaceConditionOnRadioBtn
            // 
            this.RaceConditionOnRadioBtn.AutoSize = true;
            this.RaceConditionOnRadioBtn.Location = new System.Drawing.Point(376, 128);
            this.RaceConditionOnRadioBtn.Name = "RaceConditionOnRadioBtn";
            this.RaceConditionOnRadioBtn.Size = new System.Drawing.Size(39, 17);
            this.RaceConditionOnRadioBtn.TabIndex = 5;
            this.RaceConditionOnRadioBtn.TabStop = true;
            this.RaceConditionOnRadioBtn.Text = "On";
            this.RaceConditionOnRadioBtn.UseVisualStyleBackColor = true;
            this.RaceConditionOnRadioBtn.CheckedChanged += new System.EventHandler(this.RaceConditionOnRadioBtn_CheckedChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.comboBox1.Location = new System.Drawing.Point(342, 66);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 21);
            this.comboBox1.TabIndex = 4;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // RaceConditionLable
            // 
            this.RaceConditionLable.AutoSize = true;
            this.RaceConditionLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RaceConditionLable.Location = new System.Drawing.Point(22, 114);
            this.RaceConditionLable.Name = "RaceConditionLable";
            this.RaceConditionLable.Size = new System.Drawing.Size(222, 33);
            this.RaceConditionLable.TabIndex = 3;
            this.RaceConditionLable.Text = "Race Condition:";
            // 
            // NumberOfAtmLable
            // 
            this.NumberOfAtmLable.AutoSize = true;
            this.NumberOfAtmLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumberOfAtmLable.Location = new System.Drawing.Point(22, 54);
            this.NumberOfAtmLable.Name = "NumberOfAtmLable";
            this.NumberOfAtmLable.Size = new System.Drawing.Size(240, 33);
            this.NumberOfAtmLable.TabIndex = 2;
            this.NumberOfAtmLable.Text = "Number of Atm\'s:";
            // 
            // BtnLaunch
            // 
            this.BtnLaunch.Location = new System.Drawing.Point(342, 174);
            this.BtnLaunch.Name = "BtnLaunch";
            this.BtnLaunch.Size = new System.Drawing.Size(200, 80);
            this.BtnLaunch.TabIndex = 1;
            this.BtnLaunch.Text = "Launch";
            this.BtnLaunch.UseVisualStyleBackColor = true;
            this.BtnLaunch.Click += new System.EventHandler(this.BtnLaunch_Click);
            // 
            // BtnViewLogs
            // 
            this.BtnViewLogs.Location = new System.Drawing.Point(28, 174);
            this.BtnViewLogs.Name = "BtnViewLogs";
            this.BtnViewLogs.Size = new System.Drawing.Size(200, 80);
            this.BtnViewLogs.TabIndex = 0;
            this.BtnViewLogs.Text = "View Logs";
            this.BtnViewLogs.UseVisualStyleBackColor = true;
            this.BtnViewLogs.Click += new System.EventHandler(this.BtnViewLogs_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(595, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ch_name});
            this.listView1.Location = new System.Drawing.Point(26, 77);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(530, 260);
            this.listView1.TabIndex = 6;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // ch_name
            // 
            this.ch_name.Text = "Logs";
            this.ch_name.Width = 560;
            // 
            // BankForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(595, 418);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.listView1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "BankForm";
            this.Text = "Central Bank Computer";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BtnLaunch;
        private System.Windows.Forms.Button BtnViewLogs;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label RaceConditionLable;
        private System.Windows.Forms.Label NumberOfAtmLable;
        private System.Windows.Forms.RadioButton radioButton1RaceConditionOffRadioBtn;
        private System.Windows.Forms.RadioButton RaceConditionOnRadioBtn;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader ch_name;
    }
}
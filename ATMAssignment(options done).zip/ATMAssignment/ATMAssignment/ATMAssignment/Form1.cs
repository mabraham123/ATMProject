﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATMAssignment
{
    public partial class Form1 : Form
    {
        Button[] numberpad = new Button[12];
        string value = "";
        int stage = 0;
        string pin = "";
        //string typeCheck = "AccNum";
        int accIndex;
        //int input = 0;

        public Form1()
        {
            InitializeComponent();
            InitializeNumberPad();
            GetAcountNumberFromUser();
            // CheckPinNumber();
            Program.setupAccounts();
            AccountVal();
            pinVal();
        }

        /*
         * Method to Inlitialise the numberpad
         *
         */
        private void InitializeNumberPad()
        {
            //Initlising Numberpad
            for (int i = 0; i < 9; i++)
            {
                //Inlitialising button
                numberpad[i] = new Button();
                numberpad[i].Text = Convert.ToString(i + 1);
                numberpad[i].Width = 60;
                numberpad[i].Height = 60;
                numberpad[i].Click += new EventHandler(this.btnNumberPadEvent_Click);

                //Adding button to panel
                NumberPadFlowPanel.Controls.Add(numberpad[i]);
            }

            for (int i = 9; i < 12; i++)
            {
                //Inlitialising button
                numberpad[i] = new Button();
                numberpad[i].Width = 60;
                numberpad[i].Height = 60;
                numberpad[i].Click += new EventHandler(this.btnNumberPadEvent_Click);

                //Adding button to panel
                NumberPadFlowPanel.Controls.Add(numberpad[i]);
            }

            numberpad[9].Text = "0";
            numberpad[10].Text = ".";

        }

        private void GetAcountNumberFromUser()
        {
            UserEnteredAccountNumber.Text += value;

            //Check if value is not empty
            if (UserEnteredAccountNumber.Text.Length == 6)
            {
                stage = 1;
                
                value = "";

                //Move the highlight
                PinLabel.BackColor = Color.WhiteSmoke;
                AccountLabel.BackColor = Color.RoyalBlue;
            }


        }

        private void GetPinNumberFromUser()
        {

            UserEnteredPinNumber.Text += "*";

            pin += value;

            if (UserEnteredPinNumber.Text.Length == 4)
            {
                stage = 2;
                value = "";
            }


        }


        void btnNumberPadEvent_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            value = btn.Text;
            switch (stage)
            {
                case 0: GetAcountNumberFromUser(); break;

                case 1: GetPinNumberFromUser(); break;

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnEnter_Click(object sender, EventArgs e)
        {
            
            {
                if (AccountVal() != true)
                {
                    UserEnteredAccountNumber.Text = "";
                    MessageBox.Show("Incorrect Account Details");


                }
                else
                {


                    if (pinVal() == false)
                    {
                        UserEnteredPinNumber.Text = "";
                        MessageBox.Show("Incorrect Account Details");
                        //pa
                        Withdraw f2 = new Withdraw();
                        f2.Show();

                    }
                    else
                    {
                        MessageBox.Show("Welcome To Your Account");
                    }



                }
             
            

            }
            
            
            /* string[] accNum = new string[] { "111111", "222222", "333333" };
             int i = 0;
             //while (true)
             // for (int i = 0; i < accNum.Length; i++)
             bool isValid = false;
             while (isValid != true)
             {
                 if (UserEnteredAccountNumber.Text.Equals(accNum[i]))
                 {
                     MessageBox.Show("welcome");
                     Withdraw f2 = new Withdraw();
                     f2.Show();
                     isValid = true;

                 }
                 else
                 {
                     //MessageBox.Show("enter again");
                     i++;
                 }
                */
        }
        // to convert user input to int to check against account details in account class and program class
        public bool AccountVal()
        {
            if (string.IsNullOrWhiteSpace(UserEnteredAccountNumber.Text) == false)
            {
                int value = Convert.ToInt32(UserEnteredAccountNumber.Text);
                for (int i = 0; i < 3; i++)
                {
                    if (Program.ac[i].GetAcountNumberFromUser() == value)
                    {
                        accIndex = i;
                        return true;
                    }                      

                }
                
            }
            return false;
        }
        public bool pinVal()
        {
            if (string.IsNullOrWhiteSpace(pin) == false)
            {
                int pin = Convert.ToInt32(this.pin);
                for (int i = 0; i < 3; i++)
                {

                    if (Program.ac[i].GetPinNumberFromUser() == pin)
                    {

                        return true;


                    }




                }


            }

            return false;
        }
        }

    }
        /*
         * cant check against each other i.e. account number and pin number */
         
           /*// string[] accNum = new string[] { "111111", "222222", "333333" };
            int i = 0;
            //while (true)
            // for (int i = 0; i < accNum.Length; i++)
            bool isValid = false;
            while (isValid != true)
            {
                if (UserEnteredAccountNumber.Text.Equals(accNum[i]))
                {
                    //MessageBox.Show("welcome");
                    //Withdraw f2 = new Withdraw();
                    //f2.Show();
                    isValid = true;

                }
                else
                {
                    //MessageBox.Show("enter again");
                    i++;
                }


            }
        }
        private void CheckPinNumber()
        {
            string[] pinNum = new string[] { "111111", "222222", "333333" };
            int i = 0;
            //while (true)
            // for (int i = 0; i < accNum.Length; i++)
            bool isValid = false;
            while (isValid != true)
            {
                if (UserEnteredAccountNumber.Text.Equals(pinNum[i]))
                {
                    MessageBox.Show("welcome");
                    Withdraw f2 = new Withdraw();
                    f2.Show();
                    isValid = true;

                }
                else
                {
                    //MessageBox.Show("enter again");
                    i++;
                }


            }
        }
        */
    
    



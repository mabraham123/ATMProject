﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ATMAssignment
{
    /*
     * The Account class encapusulates all features of a simple bank account
     */
    
    class Account 
    {
        //the attributes for the account
        private int balance;
        private int[] pinNumbers = new int[5];
        private int accountNum;
        private int incorrectPinAttempts;
        private Boolean frozen;


        // a constructor for indiviual accounts
        public Account(int balance, int pin, int accountNum)
        {
            this.balance = balance;
            this.pinNumbers[0] = pin;
            this.accountNum = accountNum;
            incorrectPinAttempts = 0;
            frozen = false;
        }
        // a constructor for business accounts where one account number has multiple pin numbers
        public Account(int balance, int[] pinNumbers, int accountNum)
        {
            this.balance = balance;
            this.pinNumbers = pinNumbers;
            this.accountNum = accountNum;
            incorrectPinAttempts = 0;
            frozen = false;
        }

        /*
         * Returns the account balance
         *Return:
         * Account balance
         */
        public int getBalance()
        {
        
            return balance;
            
        }

        /*
         * Sets the account balance
         *Parameter:
         * newBalance- the new balance for the account
         */
        public void setBalance(int newBalance)
        {
            this.balance = newBalance;
        }

        /*
         *   This funciton allows us to decrement the balance of an account
         *   it perfomes a simple check to ensure the balance is greater than
         *   the amount being debeted
         *   
         *   returns:
         *   true if the transactions if possible
         *   false if there are insufficent funds in the account
         */
        public Boolean decrementBalance(int amount)
        {
            //Checking if there is sufficient funds to withdraw money
            if (this.balance >= amount)
            {
                //withdraw money
                balance -= amount;
                //artificial sleep
                Thread.Sleep(3000);
                //Withdraw successfull
                return true;
            }

            //Unsuccessfull withdrawl
            //insufficient funds
                return false;
        }

        /*
         * This funciton check the account pin number(s) against the argument passed to it
         *Parameters:
         * pinEntered- User entered pin number
         *Returns:
         * If the pin number is valid
         */
        public Boolean checkPin(int pinEntered)
        {
            //Get the length of the array that holds pin numbers
            int lengthOfArray = pinNumbers.Length;

            //Check if pin is in pinNumber arrays
            for(int i=0;i< lengthOfArray; i++) {
                //Check if index hold the pin number
                if (pinEntered== pinNumbers[i]) {
                //Pin found
                    return true;
                }
            }

            //Pin was not found
            return false;


        }

        /*
         * Function returns the account number
         *Returns:
         * account number
         */
        public int getAccountNum()
        {
            return accountNum;
        }

        /*
        * Function returns the number of incorrect attempts at entering PIN
        *Returns:
        * number of incorrect attempts at entering PIN
        */
        public int GetIncorrectPinAttempts()
        {
            return incorrectPinAttempts;
        }

        /*
         * This function increments the number of incorrect attempts at entering the PIN
         */
        public void IncrementIncorrectPinAttempts()
        {
            incorrectPinAttempts += 1;
        }

        /*
         * Function returns if the account has been frozen
         *Returns:
         * true if the account has been frozen
         * false if the account is active
         */
        public Boolean IsFrozen()
        {
            return frozen;
        }

        /*
         * This function freezes the account by setting frozen to be true
         */
        public void FreezeAccount()
        {
            frozen = true;
        }
    }
}

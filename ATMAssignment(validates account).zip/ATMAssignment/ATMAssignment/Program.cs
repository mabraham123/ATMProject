﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace ATMAssignment
{
    static class Program
    {
        public static Account[] ac = new Account[3];

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //initialise accounts
            ac[0] = new Account(300, 1111, 111111);
            ac[1] = new Account(750, 2222, 222222);
            ac[2] = new Account(3000, 3333, 333333);

            //original run form code
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new ATMForm());

            /*
            //threading run form code
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Thread atm_t = new Thread(ThreadStart);
            // allow UI with ApartmentState.STA though [STAThread] above should give that to you
            atm_t.TrySetApartmentState(ApartmentState.STA);
            atm_t.Start();

            Application.Run(new ATMForm(ac));*/
        }

        private static void ThreadStart()
        {
            Application.Run(new ATMForm()); // <-- other form started on its own UI thread
        }
    }

}
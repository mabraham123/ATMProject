﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATMAssignment
{
    public partial class ATMForm : Form
    {
        private Account activeAccount = null;
        Button[] numberpad = new Button[12];
        string value = "";
        int stage = 0;
        string pin = "";
        int option; //
         
        public ATMForm()
        {
            InitializeComponent();
            InitializeNumberPad();
            InitializePanelOptions();
            GetAcountNumberFromUser();
        }

        /*
         * Method to Inlitialise the numberpad
         *
         */ 
        private void InitializeNumberPad() {
            //Initlising Numberpad
            for (int i = 0; i < 9; i++)
            {
                //Inlitialising button
                numberpad[i] = new Button();
                numberpad[i].Text = Convert.ToString(i + 1);
                numberpad[i].Width = 60;
                numberpad[i].Height = 60;
                numberpad[i].Click += new EventHandler(this.BtnNumberPadEvent_Click);

                //Adding button to panel
                NumberPadFlowPanel.Controls.Add(numberpad[i]);
            }

            for (int i = 9; i < 12; i++)
            {
                //Inlitialising button
                numberpad[i] = new Button();
                numberpad[i].Width = 60;
                numberpad[i].Height = 60;
                numberpad[i].Click += new EventHandler(this.BtnNumberPadEvent_Click);

                //Adding button to panel
                NumberPadFlowPanel.Controls.Add(numberpad[i]);
            }

            numberpad[9].Text = "0";
            numberpad[10].Text = ".";
            
        }

        private void GetAcountNumberFromUser() {
            UserEnteredAccountNumber.Text += value;

            //Check if value is not empty
            if (UserEnteredAccountNumber.Text.Length == 6)
            {
                stage = 1;
                value = "";

                //Move the highlight
                PinLabel.BackColor = Color.WhiteSmoke;
                AccountLabel.BackColor = Color.RoyalBlue;
            }

            
        }

        private void GetPinNumberFromUser(){

            UserEnteredPinNumber.Text += "*";
            pin += value;

            if (UserEnteredPinNumber.Text.Length == 4) {
                stage = 2;
                value = "";

                //Move the highlight
                lEnter.BackColor = Color.WhiteSmoke;
                PinLabel.BackColor = Color.RoyalBlue;
            }

          
    }


        void BtnNumberPadEvent_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            value = btn.Text;
            switch (stage)
            {
                case 0: GetAcountNumberFromUser(); break;

                case 1: GetPinNumberFromUser(); break;

                //case : ; break;

                default: break;

            }
        }

        void BtnOptionsEvent_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            //option = ;

        }

        private void InitializePanelOptions()
        {
            panelOptions.Visible = false;
            lOption4.Visible = false;
            lOption5.Visible = false;
        }

        /*
         *    this method finds an account with the account number the user entered
         *    the string account number is converted to an int then
         *    a for loop is used to check the entered account number
         *    against those held in the account array
         *    if a match is found a reference to the match is returned
         *    if the for loop completes with no match we return null
         * 
         */
        private Account FindAccount()
        {
            int input = Convert.ToInt32(UserEnteredAccountNumber.Text);

            for (int i = 0; i < Program.ac.Length; i++)
            {
                if (Program.ac[i].getAccountNum() == input)
                {
                    return Program.ac[i];
                }
            }

            return null;
        }

        //checks if the user has entered a valid account with the correct pin
        private void ValidateAccount()
        {
            activeAccount = FindAccount();
            if (activeAccount == null)
            {
                //clear stored values
                UserEnteredAccountNumber.Text = "";
                UserEnteredPinNumber.Text = "";
                pin = "";
                stage = 0;

                //Move the highlight
                AccountLabel.BackColor = Color.WhiteSmoke;
                lEnter.BackColor = Color.RoyalBlue;

                MessageBox.Show("Incorrect Account Details");
            }
            else
            {
                int intPin = Convert.ToInt32(pin);
                if (activeAccount.checkPin(intPin))
                {
                    MessageBox.Show("Welcome To Your Account");
                    panelOptions.Visible = true;
                }
                else
                {
                    //clear stored values
                    UserEnteredAccountNumber.Text = "";
                    UserEnteredPinNumber.Text = "";
                    pin = "";
                    stage = 0;

                    //Move the highlight
                    AccountLabel.BackColor = Color.WhiteSmoke;
                    lEnter.BackColor = Color.RoyalBlue;

                    MessageBox.Show("Incorrect Account Details");
                }
            }
        }

        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            ValidateAccount();
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult aboutDialog = new DialogResult();
            aboutDialog = MessageBox.Show("Multi Threaded ATM programmed in C# by Naqash Nadeem, Nicole Orr and Melvin Abraham", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

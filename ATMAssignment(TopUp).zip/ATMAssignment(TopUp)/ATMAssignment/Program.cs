﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace ATMAssignment
{
    static class Program
    {
        public static Account[] ac = new Account[3];

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            SetupAccounts(); //Set up the bank accounts to be used
            SetupLogs(); //Set up a bank log

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new ADD_InputBox_To_Csharp());
            Application.Run(new BankForm());
        }

        /*
         * Method to clear a file if it exists
         */
        private static void SetupLogs() {
            //If a file exists
            if (File.Exists(@"../../BankLog.txt"))
            {
                //The functionality of clearing al the text in a file is from the user "SLaks" alternetive solution
                //https://stackoverflow.com/questions/2695444/clearing-content-of-text-file-using-c-sharp
                //Last accessed: 26/03/2019
                File.WriteAllText(@"../../BankLog.txt", String.Empty);
            }
        }

        /*
         * Function sets up the accounts for the atm
         * both business accounts and individual accounts
         */
        private static void SetupAccounts() {
            //Set up pin numbers array to demonstrate business accounts
            int[] pinNumbers = new int[2];
            pinNumbers[0] = 1111;
            pinNumbers[1] = 2222;

            //initialise accounts
            ac[0] = new Account(300, pinNumbers, 111111);
            ac[1] = new Account(750, 2222, 222222);
            ac[2] = new Account(3000, 3333, 333333);
        }

        /*
        * Function to create a bank log text file
        */
        private static void CreateLog()
        {
            StreamWriter sw = File.CreateText(@"../../BankLog.txt");
            sw.WriteLine("Bank Log:");
            sw.Close();
        }

        /*
         * Function to add to the bank log text file
         */
        public static void AddToLog(string info)
        {
            using (StreamWriter sw = File.AppendText(@"../../BankLog.txt"))
            {
                sw.WriteLine(DateTime.Now.ToLongTimeString() + " " + info); //writes a timestamp and the information to file
                sw.Close();
            }
        }
    }

}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace ATMAssignment
{
    public partial class Form1 : Form
    {
        Button[] numberpad = new Button[12];
        string value = "";
        int stage = 0;
        string pin = "";
         
        public Form1()
        {
            InitializeComponent();
            InitializeNumberPad();
            GetAcountNumberFromUser();
        }

        /*
         * Method to Inlitialise the numberpad
         *
         */ 
        private void InitializeNumberPad() {
            //Initlising Numberpad
            for (int i = 0; i < 9; i++)
            {
                //Inlitialising button
                numberpad[i] = new Button();
                numberpad[i].Text = Convert.ToString(i + 1);
                numberpad[i].Width = 60;
                numberpad[i].Height = 60;
                numberpad[i].Click += new EventHandler(this.btnNumberPadEvent_Click);

                //Adding button to panel
                NumberPadFlowPanel.Controls.Add(numberpad[i]);
            }

            for (int i = 9; i < 12; i++)
            {
                //Inlitialising button
                numberpad[i] = new Button();
                numberpad[i].Width = 60;
                numberpad[i].Height = 60;
                numberpad[i].Click += new EventHandler(this.btnNumberPadEvent_Click);

                //Adding button to panel
                NumberPadFlowPanel.Controls.Add(numberpad[i]);
            }

            numberpad[9].Text = "0";
            numberpad[10].Text = ".";
            
        }

        private void GetAcountNumberFromUser() {
            UserEnteredAccountNumber.Text += value;

            //Check if value is not empty
            if (UserEnteredAccountNumber.Text.Length == 6)
            {
                stage = 1;
                value = "";

                //Move the highlight
                PinLabel.BackColor = Color.WhiteSmoke;
                AccountLabel.BackColor = Color.RoyalBlue;
            }

            
        }

        private void GetPinNumberFromUser(){

            UserEnteredPinNumber.Text += "*";

                   pin+=value;

            if (UserEnteredPinNumber.Text.Length==4) {
                stage = 2;
                value = "";
            }

          
    }


        void btnNumberPadEvent_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            value = btn.Text;
            switch (stage)
            {
                case 0: GetAcountNumberFromUser(); break;

                case 1: GetPinNumberFromUser(); break;

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult aboutDialog = new DialogResult();
            aboutDialog = MessageBox.Show("Multi Threaded ATM programmed in C# by Naqash Nadeem, Nicole Orr and Melvin Abraham", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

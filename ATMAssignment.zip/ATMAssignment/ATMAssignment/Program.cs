﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace ATMAssignment
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Thread atm_t = new Thread(ThreadStart);
            // allow UI with ApartmentState.STA though [STAThread] above should give that to you
           atm_t.TrySetApartmentState(ApartmentState.STA);
            atm_t.Start();

            Application.Run(new Form1());
        }




        private static void ThreadStart()
        {
            Application.Run(new Form1()); // <-- other form started on its own UI thread
        }
    }
}

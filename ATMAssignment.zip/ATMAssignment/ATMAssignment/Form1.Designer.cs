﻿namespace ATMAssignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnOption1 = new System.Windows.Forms.Button();
            this.BtnOption2 = new System.Windows.Forms.Button();
            this.BtnOption3 = new System.Windows.Forms.Button();
            this.BtnOption6 = new System.Windows.Forms.Button();
            this.BtnOption5 = new System.Windows.Forms.Button();
            this.BtnOption4 = new System.Windows.Forms.Button();
            this.AccountLabel = new System.Windows.Forms.Label();
            this.UserEnteredAccountNumber = new System.Windows.Forms.Label();
            this.PinLabel = new System.Windows.Forms.Label();
            this.UserEnteredPinNumber = new System.Windows.Forms.Label();
            this.NumberPadFlowPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(675, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // BtnOption1
            // 
            this.BtnOption1.Location = new System.Drawing.Point(25, 71);
            this.BtnOption1.Name = "BtnOption1";
            this.BtnOption1.Size = new System.Drawing.Size(60, 60);
            this.BtnOption1.TabIndex = 1;
            this.BtnOption1.Text = ">";
            this.BtnOption1.UseVisualStyleBackColor = true;
            // 
            // BtnOption2
            // 
            this.BtnOption2.Location = new System.Drawing.Point(25, 164);
            this.BtnOption2.Name = "BtnOption2";
            this.BtnOption2.Size = new System.Drawing.Size(60, 60);
            this.BtnOption2.TabIndex = 2;
            this.BtnOption2.Text = ">";
            this.BtnOption2.UseVisualStyleBackColor = true;
            // 
            // BtnOption3
            // 
            this.BtnOption3.BackColor = System.Drawing.Color.Red;
            this.BtnOption3.Location = new System.Drawing.Point(25, 257);
            this.BtnOption3.Name = "BtnOption3";
            this.BtnOption3.Size = new System.Drawing.Size(60, 60);
            this.BtnOption3.TabIndex = 3;
            this.BtnOption3.Text = ">";
            this.BtnOption3.UseVisualStyleBackColor = false;
            // 
            // BtnOption6
            // 
            this.BtnOption6.BackColor = System.Drawing.Color.ForestGreen;
            this.BtnOption6.Location = new System.Drawing.Point(586, 257);
            this.BtnOption6.Name = "BtnOption6";
            this.BtnOption6.Size = new System.Drawing.Size(60, 60);
            this.BtnOption6.TabIndex = 6;
            this.BtnOption6.Text = "<";
            this.BtnOption6.UseVisualStyleBackColor = false;
            // 
            // BtnOption5
            // 
            this.BtnOption5.Location = new System.Drawing.Point(586, 164);
            this.BtnOption5.Name = "BtnOption5";
            this.BtnOption5.Size = new System.Drawing.Size(60, 60);
            this.BtnOption5.TabIndex = 5;
            this.BtnOption5.Text = "<";
            this.BtnOption5.UseVisualStyleBackColor = true;
            // 
            // BtnOption4
            // 
            this.BtnOption4.Location = new System.Drawing.Point(586, 71);
            this.BtnOption4.Name = "BtnOption4";
            this.BtnOption4.Size = new System.Drawing.Size(60, 60);
            this.BtnOption4.TabIndex = 4;
            this.BtnOption4.Text = "<";
            this.BtnOption4.UseVisualStyleBackColor = true;
            // 
            // AccountLabel
            // 
            this.AccountLabel.AutoSize = true;
            this.AccountLabel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.AccountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountLabel.Location = new System.Drawing.Point(109, 84);
            this.AccountLabel.Name = "AccountLabel";
            this.AccountLabel.Size = new System.Drawing.Size(348, 31);
            this.AccountLabel.TabIndex = 7;
            this.AccountLabel.Text = "Enter your account number:";
            // 
            // UserEnteredAccountNumber
            // 
            this.UserEnteredAccountNumber.AutoSize = true;
            this.UserEnteredAccountNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserEnteredAccountNumber.Location = new System.Drawing.Point(465, 94);
            this.UserEnteredAccountNumber.Name = "UserEnteredAccountNumber";
            this.UserEnteredAccountNumber.Size = new System.Drawing.Size(0, 20);
            this.UserEnteredAccountNumber.TabIndex = 8;
            // 
            // PinLabel
            // 
            this.PinLabel.AutoSize = true;
            this.PinLabel.BackColor = System.Drawing.Color.RoyalBlue;
            this.PinLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PinLabel.Location = new System.Drawing.Point(109, 173);
            this.PinLabel.Name = "PinLabel";
            this.PinLabel.Size = new System.Drawing.Size(288, 31);
            this.PinLabel.TabIndex = 9;
            this.PinLabel.Text = "Enter your pin number:";
            // 
            // UserEnteredPinNumber
            // 
            this.UserEnteredPinNumber.AutoSize = true;
            this.UserEnteredPinNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserEnteredPinNumber.Location = new System.Drawing.Point(465, 181);
            this.UserEnteredPinNumber.Name = "UserEnteredPinNumber";
            this.UserEnteredPinNumber.Size = new System.Drawing.Size(0, 20);
            this.UserEnteredPinNumber.TabIndex = 10;
            // 
            // NumberPadFlowPanel
            // 
            this.NumberPadFlowPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumberPadFlowPanel.Location = new System.Drawing.Point(219, 350);
            this.NumberPadFlowPanel.Name = "NumberPadFlowPanel";
            this.NumberPadFlowPanel.Size = new System.Drawing.Size(238, 329);
            this.NumberPadFlowPanel.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(109, 275);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 31);
            this.label2.TabIndex = 12;
            this.label2.Text = "Cancel";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(475, 275);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 31);
            this.label3.TabIndex = 13;
            this.label3.Text = "Enter";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel1.Location = new System.Drawing.Point(92, 71);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(488, 246);
            this.panel1.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 761);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.NumberPadFlowPanel);
            this.Controls.Add(this.UserEnteredPinNumber);
            this.Controls.Add(this.PinLabel);
            this.Controls.Add(this.UserEnteredAccountNumber);
            this.Controls.Add(this.AccountLabel);
            this.Controls.Add(this.BtnOption6);
            this.Controls.Add(this.BtnOption5);
            this.Controls.Add(this.BtnOption4);
            this.Controls.Add(this.BtnOption3);
            this.Controls.Add(this.BtnOption2);
            this.Controls.Add(this.BtnOption1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "ATM Assignment";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button BtnOption1;
        private System.Windows.Forms.Button BtnOption2;
        private System.Windows.Forms.Button BtnOption3;
        private System.Windows.Forms.Button BtnOption6;
        private System.Windows.Forms.Button BtnOption5;
        private System.Windows.Forms.Button BtnOption4;
        private System.Windows.Forms.Label AccountLabel;
        private System.Windows.Forms.Label UserEnteredAccountNumber;
        private System.Windows.Forms.Label PinLabel;
        private System.Windows.Forms.Label UserEnteredPinNumber;
        private System.Windows.Forms.FlowLayoutPanel NumberPadFlowPanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATMAssignment
{
    class Account
    {
        private int accNum;
        private int pinNum;

        public Account(int accNum, int pinNum)
        {
            
            this.accNum = accNum;
            this.pinNum = accNum;
        }
        public int GetAcountNumberFromUser()
        {
            return accNum;
        }

        public int GetPinNumberFromUser()
        {
            return pinNum;
        }

        public Boolean checkPin(int pinEntered)
        {
            if (pinEntered == pinNum)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

    }
}
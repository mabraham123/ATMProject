﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace ATMAssignment
{
    static class Program
    {
        public static Account[] ac = new Account[3];

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            setupAccounts();

            
            /*  //original run form code
              Application.EnableVisualStyles();
              Application.SetCompatibleTextRenderingDefault(false);
              Application.Run(new ATMForm());
            */


            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //Threading 
            //Create new thread
            //Thread atm_t = new Thread(ThreadStart);
            //Start the threading
            //atm_t.TrySetApartmentState(ApartmentState.STA);
            //atm_t.Start();

            Application.Run(new BankForm());
            //Application.Run(new ATMForm(true));
        }

        /*
         * Function runs the new thread
         */
        private static void ThreadStart()
        {
            //run new thread
            Application.Run(new ATMForm(true)); 
        }

        /*
         * Function sets up the accounts for the atm
         * both business accounts and individual accounts
         */
        private static void setupAccounts() {
            //Set up pin numbers array to demonstrate business accounts
            int[] pinNumbers = new int[2];
            pinNumbers[0] = 1111;
            pinNumbers[1] = 2222;

            //initialise accounts
            ac[0] = new Account(300, pinNumbers, 111111);
            ac[1] = new Account(750, 2222, 222222);
            ac[2] = new Account(3000, 3333, 333333);
        }

        private static void CreateLog()
        {
            StreamWriter sw = File.CreateText(@"../../BankLog.txt");
            sw.WriteLine("Bank Log:");
            sw.Close();
        }

        public static void AddToLog(string info)
        {
            using (StreamWriter sw = File.AppendText(@"../../BankLog.txt"))
            {
                sw.WriteLine(DateTime.Now.ToLongTimeString() + " " + info);
                sw.Close();
            }
        }
    }

}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace ATMAssignment
{
    public partial class BankForm : Form
    {
        private static int numberOfAtms = 0;
        private static bool isRaceConditionOn = false;
        public BankForm()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult aboutDialog = new DialogResult();
            aboutDialog = MessageBox.Show("Multi Threaded ATM programmed in C# by Naqash Nadeem, Nicole Orr and Melvin Abraham", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void RaceConditionOnRadioBtn_CheckedChanged(object sender, EventArgs e)
        {
            isRaceConditionOn = true;
        }

        private void radioButton1RaceConditionOffRadioBtn_CheckedChanged(object sender, EventArgs e)
        {
            isRaceConditionOn = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            numberOfAtms = Convert.ToInt32(comboBox1.Text);
        }

        private void BtnLaunch_Click(object sender, EventArgs e)
        {
            //Setup threads for number of ATM
            Thread[] atms = new Thread[numberOfAtms];
            for (int i = 0; i < numberOfAtms; i++) {
                atms[i] = new Thread(ThreadStart);
                atms[i].Start();
            }

            //Get Race conditions
        }
        /*
         * Function runs the new thread
         */
        private static void ThreadStart()
        {
            //Create the ATM with the correct racecondition setting
            Application.Run(new ATMForm(isRaceConditionOn));

        }

        private void BtnViewLogs_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void ReadFromFile() {
            //Read in data from file and store in an array
            //Read in data from file and store in an array
            string[] logFromFile = File.ReadAllLines(@"../../BankLog.txt");

            //Variables to hold all the data for one instance of a game together
            String name = "";

            //Go through all the scores and display them to the table
            for (int counter = 0; counter < logFromFile.Length; counter++)
            {
                //Save the data into their respective varaibles
                name = logFromFile[counter];


                //Add the data into the list view
                ListViewItem scores = new ListViewItem(name);
                scores.SubItems.Add(name);

                listView1.Items.Add(scores);
            }
        }

       
    }
}

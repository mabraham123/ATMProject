﻿namespace ATMAssignment
{
    partial class ATMForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ATMForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnOption1 = new System.Windows.Forms.Button();
            this.BtnOption2 = new System.Windows.Forms.Button();
            this.BtnOption3 = new System.Windows.Forms.Button();
            this.BtnConfirm = new System.Windows.Forms.Button();
            this.BtnOption5 = new System.Windows.Forms.Button();
            this.BtnOption4 = new System.Windows.Forms.Button();
            this.lAccount = new System.Windows.Forms.Label();
            this.UserEnteredAccountNumber = new System.Windows.Forms.Label();
            this.lPin = new System.Windows.Forms.Label();
            this.UserEnteredPinNumber = new System.Windows.Forms.Label();
            this.NumberPadFlowPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.lCancel = new System.Windows.Forms.Label();
            this.lEnter = new System.Windows.Forms.Label();
            this.panelScreen = new System.Windows.Forms.Panel();
            this.panelOptions = new System.Windows.Forms.Panel();
            this.LoadingPanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LoadingText = new System.Windows.Forms.Label();
            this.lOption5 = new System.Windows.Forms.Label();
            this.lOption4 = new System.Windows.Forms.Label();
            this.lOption3 = new System.Windows.Forms.Label();
            this.lOption2 = new System.Windows.Forms.Label();
            this.lOption1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.panelOptions.SuspendLayout();
            this.LoadingPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(675, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.AboutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);
            // 
            // BtnOption1
            // 
            this.BtnOption1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOption1.Location = new System.Drawing.Point(25, 71);
            this.BtnOption1.Name = "BtnOption1";
            this.BtnOption1.Size = new System.Drawing.Size(60, 60);
            this.BtnOption1.TabIndex = 1;
            this.BtnOption1.Text = ">";
            this.BtnOption1.UseVisualStyleBackColor = true;
            this.BtnOption1.Click += new System.EventHandler(this.BtnOption1_Click);
            // 
            // BtnOption2
            // 
            this.BtnOption2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOption2.Location = new System.Drawing.Point(25, 164);
            this.BtnOption2.Name = "BtnOption2";
            this.BtnOption2.Size = new System.Drawing.Size(60, 60);
            this.BtnOption2.TabIndex = 2;
            this.BtnOption2.Text = ">";
            this.BtnOption2.UseVisualStyleBackColor = true;
            this.BtnOption2.Click += new System.EventHandler(this.BtnOption2_Click);
            // 
            // BtnOption3
            // 
            this.BtnOption3.BackColor = System.Drawing.Color.Red;
            this.BtnOption3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOption3.Location = new System.Drawing.Point(25, 257);
            this.BtnOption3.Name = "BtnOption3";
            this.BtnOption3.Size = new System.Drawing.Size(60, 60);
            this.BtnOption3.TabIndex = 3;
            this.BtnOption3.Text = ">";
            this.BtnOption3.UseVisualStyleBackColor = false;
            this.BtnOption3.Click += new System.EventHandler(this.BtnOption3_Click);
            // 
            // BtnConfirm
            // 
            this.BtnConfirm.BackColor = System.Drawing.Color.ForestGreen;
            this.BtnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnConfirm.Location = new System.Drawing.Point(586, 257);
            this.BtnConfirm.Name = "BtnConfirm";
            this.BtnConfirm.Size = new System.Drawing.Size(60, 60);
            this.BtnConfirm.TabIndex = 6;
            this.BtnConfirm.Text = "<";
            this.BtnConfirm.UseVisualStyleBackColor = false;
            this.BtnConfirm.Click += new System.EventHandler(this.BtnConfirm_ClickAsync);
            // 
            // BtnOption5
            // 
            this.BtnOption5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOption5.Location = new System.Drawing.Point(586, 164);
            this.BtnOption5.Name = "BtnOption5";
            this.BtnOption5.Size = new System.Drawing.Size(60, 60);
            this.BtnOption5.TabIndex = 5;
            this.BtnOption5.Text = "<";
            this.BtnOption5.UseVisualStyleBackColor = true;
            this.BtnOption5.Click += new System.EventHandler(this.BtnOption5_Click);
            // 
            // BtnOption4
            // 
            this.BtnOption4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOption4.Location = new System.Drawing.Point(586, 71);
            this.BtnOption4.Name = "BtnOption4";
            this.BtnOption4.Size = new System.Drawing.Size(60, 60);
            this.BtnOption4.TabIndex = 4;
            this.BtnOption4.Text = "<";
            this.BtnOption4.UseVisualStyleBackColor = true;
            this.BtnOption4.Click += new System.EventHandler(this.BtnOption4_Click);
            // 
            // lAccount
            // 
            this.lAccount.AutoSize = true;
            this.lAccount.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lAccount.Location = new System.Drawing.Point(109, 84);
            this.lAccount.Name = "lAccount";
            this.lAccount.Size = new System.Drawing.Size(348, 31);
            this.lAccount.TabIndex = 7;
            this.lAccount.Text = "Enter your account number:";
            // 
            // UserEnteredAccountNumber
            // 
            this.UserEnteredAccountNumber.AutoSize = true;
            this.UserEnteredAccountNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserEnteredAccountNumber.Location = new System.Drawing.Point(465, 94);
            this.UserEnteredAccountNumber.Name = "UserEnteredAccountNumber";
            this.UserEnteredAccountNumber.Size = new System.Drawing.Size(0, 20);
            this.UserEnteredAccountNumber.TabIndex = 8;
            // 
            // lPin
            // 
            this.lPin.AutoSize = true;
            this.lPin.BackColor = System.Drawing.Color.RoyalBlue;
            this.lPin.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPin.Location = new System.Drawing.Point(109, 173);
            this.lPin.Name = "lPin";
            this.lPin.Size = new System.Drawing.Size(288, 31);
            this.lPin.TabIndex = 9;
            this.lPin.Text = "Enter your pin number:";
            // 
            // UserEnteredPinNumber
            // 
            this.UserEnteredPinNumber.AutoSize = true;
            this.UserEnteredPinNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserEnteredPinNumber.Location = new System.Drawing.Point(465, 181);
            this.UserEnteredPinNumber.Name = "UserEnteredPinNumber";
            this.UserEnteredPinNumber.Size = new System.Drawing.Size(0, 20);
            this.UserEnteredPinNumber.TabIndex = 10;
            // 
            // NumberPadFlowPanel
            // 
            this.NumberPadFlowPanel.BackColor = System.Drawing.Color.Transparent;
            this.NumberPadFlowPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumberPadFlowPanel.Location = new System.Drawing.Point(219, 350);
            this.NumberPadFlowPanel.Name = "NumberPadFlowPanel";
            this.NumberPadFlowPanel.Size = new System.Drawing.Size(238, 329);
            this.NumberPadFlowPanel.TabIndex = 11;
            // 
            // lCancel
            // 
            this.lCancel.AutoSize = true;
            this.lCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lCancel.Location = new System.Drawing.Point(109, 275);
            this.lCancel.Name = "lCancel";
            this.lCancel.Size = new System.Drawing.Size(99, 31);
            this.lCancel.TabIndex = 12;
            this.lCancel.Text = "Cancel";
            // 
            // lEnter
            // 
            this.lEnter.AutoSize = true;
            this.lEnter.BackColor = System.Drawing.Color.RoyalBlue;
            this.lEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lEnter.Location = new System.Drawing.Point(475, 275);
            this.lEnter.Name = "lEnter";
            this.lEnter.Size = new System.Drawing.Size(79, 31);
            this.lEnter.TabIndex = 13;
            this.lEnter.Text = "Enter";
            // 
            // panelScreen
            // 
            this.panelScreen.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelScreen.Location = new System.Drawing.Point(92, 71);
            this.panelScreen.Name = "panelScreen";
            this.panelScreen.Size = new System.Drawing.Size(488, 246);
            this.panelScreen.TabIndex = 14;
            // 
            // panelOptions
            // 
            this.panelOptions.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelOptions.Controls.Add(this.LoadingPanel);
            this.panelOptions.Controls.Add(this.lOption5);
            this.panelOptions.Controls.Add(this.lOption4);
            this.panelOptions.Controls.Add(this.lOption3);
            this.panelOptions.Controls.Add(this.lOption2);
            this.panelOptions.Controls.Add(this.lOption1);
            this.panelOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelOptions.Location = new System.Drawing.Point(91, 71);
            this.panelOptions.Name = "panelOptions";
            this.panelOptions.Size = new System.Drawing.Size(488, 247);
            this.panelOptions.TabIndex = 0;
            // 
            // LoadingPanel
            // 
            this.LoadingPanel.Controls.Add(this.pictureBox1);
            this.LoadingPanel.Controls.Add(this.LoadingText);
            this.LoadingPanel.Location = new System.Drawing.Point(0, 0);
            this.LoadingPanel.Name = "LoadingPanel";
            this.LoadingPanel.Size = new System.Drawing.Size(489, 247);
            this.LoadingPanel.TabIndex = 6;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ATMAssignment.Properties.Resources.Infinity_5s_200px;
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(127, 42);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 164);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // LoadingText
            // 
            this.LoadingText.AutoSize = true;
            this.LoadingText.Location = new System.Drawing.Point(82, 8);
            this.LoadingText.Name = "LoadingText";
            this.LoadingText.Size = new System.Drawing.Size(299, 31);
            this.LoadingText.TabIndex = 1;
            this.LoadingText.Text = "Validating your Account";
            // 
            // lOption5
            // 
            this.lOption5.AutoSize = true;
            this.lOption5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lOption5.Location = new System.Drawing.Point(324, 108);
            this.lOption5.Name = "lOption5";
            this.lOption5.Size = new System.Drawing.Size(60, 25);
            this.lOption5.TabIndex = 5;
            this.lOption5.Text = "£500";
            this.lOption5.Visible = false;
            // 
            // lOption4
            // 
            this.lOption4.AutoSize = true;
            this.lOption4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lOption4.Location = new System.Drawing.Point(324, 14);
            this.lOption4.Name = "lOption4";
            this.lOption4.Size = new System.Drawing.Size(159, 25);
            this.lOption4.TabIndex = 4;
            this.lOption4.Text = "Make a deposit";
            this.lOption4.Visible = false;
            // 
            // lOption3
            // 
            this.lOption3.AutoSize = true;
            this.lOption3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lOption3.Location = new System.Drawing.Point(9, 201);
            this.lOption3.Name = "lOption3";
            this.lOption3.Size = new System.Drawing.Size(124, 25);
            this.lOption3.TabIndex = 3;
            this.lOption3.Text = "Return card";
            // 
            // lOption2
            // 
            this.lOption2.AutoSize = true;
            this.lOption2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lOption2.Location = new System.Drawing.Point(9, 108);
            this.lOption2.Name = "lOption2";
            this.lOption2.Size = new System.Drawing.Size(237, 25);
            this.lOption2.TabIndex = 2;
            this.lOption2.Text = "Check account balance";
            // 
            // lOption1
            // 
            this.lOption1.AutoSize = true;
            this.lOption1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lOption1.Location = new System.Drawing.Point(5, 14);
            this.lOption1.Name = "lOption1";
            this.lOption1.Size = new System.Drawing.Size(301, 25);
            this.lOption1.TabIndex = 1;
            this.lOption1.Text = "Withdraw money from account";
            // 
            // ATMForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(675, 749);
            this.Controls.Add(this.panelOptions);
            this.Controls.Add(this.lEnter);
            this.Controls.Add(this.lCancel);
            this.Controls.Add(this.NumberPadFlowPanel);
            this.Controls.Add(this.UserEnteredPinNumber);
            this.Controls.Add(this.lPin);
            this.Controls.Add(this.UserEnteredAccountNumber);
            this.Controls.Add(this.lAccount);
            this.Controls.Add(this.BtnConfirm);
            this.Controls.Add(this.BtnOption5);
            this.Controls.Add(this.BtnOption4);
            this.Controls.Add(this.BtnOption3);
            this.Controls.Add(this.BtnOption2);
            this.Controls.Add(this.BtnOption1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panelScreen);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "ATMForm";
            this.Text = "ATM Assignment";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelOptions.ResumeLayout(false);
            this.panelOptions.PerformLayout();
            this.LoadingPanel.ResumeLayout(false);
            this.LoadingPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button BtnOption1;
        private System.Windows.Forms.Button BtnOption2;
        private System.Windows.Forms.Button BtnOption3;
        private System.Windows.Forms.Button BtnConfirm;
        private System.Windows.Forms.Button BtnOption5;
        private System.Windows.Forms.Button BtnOption4;
        private System.Windows.Forms.Label lAccount;
        private System.Windows.Forms.Label UserEnteredAccountNumber;
        private System.Windows.Forms.Label lPin;
        private System.Windows.Forms.Label UserEnteredPinNumber;
        private System.Windows.Forms.FlowLayoutPanel NumberPadFlowPanel;
        private System.Windows.Forms.Label lCancel;
        private System.Windows.Forms.Label lEnter;
        private System.Windows.Forms.Panel panelScreen;
        private System.Windows.Forms.Panel panelOptions;
        private System.Windows.Forms.Label lOption5;
        private System.Windows.Forms.Label lOption4;
        private System.Windows.Forms.Label lOption3;
        private System.Windows.Forms.Label lOption2;
        private System.Windows.Forms.Label lOption1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel LoadingPanel;
        private System.Windows.Forms.Label LoadingText;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

